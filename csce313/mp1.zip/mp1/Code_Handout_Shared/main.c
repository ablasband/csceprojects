#include "ackerman.h"

int main(int argc, char ** argv) {
  ackerman_main();
}
